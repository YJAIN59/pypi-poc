def toggle(str1):
    return str1.swapcase()